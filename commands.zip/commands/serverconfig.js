const { Command } = require('discord.js-commando');

module.exports = class ServerConfigCommand extends Command {
    constructor(client) {
        super(client, {
            name: 'serverconfig',
            group: 'custom',
            memberName: 'serverconfig',
            description: 'Learn how to use the server.xml configuration file.',
        });
    }

    run(message) {
        // Provide the configuration guide URL to the user
        const configURL = 'https://wiki.gtaconnected.com/ServerConfiguration';
        message.reply(`To learn how to use the server.xml configuration file, please follow this guide: ${configURL}`);
    }
};
