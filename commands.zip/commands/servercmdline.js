const { Command } = require('discord.js-commando');

module.exports = class ServerCmdLineCommand extends Command {
    constructor(client) {
        super(client, {
            name: 'servercmdline',
            group: 'custom',
            memberName: 'servercmdline',
            description: 'The server supports command line options that override XML configuration settings.',
        });
    }

    run(message) {
        // Provide the command line options guide URL to the user
        const cmdlineURL = 'https://wiki.gtaconnected.com/ServerCommandLine';
        message.reply(`To learn about using command line options, please access this guide: ${cmdlineURL}`);
    }
};
