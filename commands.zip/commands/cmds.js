const { Command } = require('discord.js-commando');

module.exports = class CommandsCommand extends Command {
    constructor(client) {
        super(client, {
            name: 'cmds',
            group: 'custom',
            memberName: 'cmds',
            description: 'List available commands in categories.',
        });
    }

    run(message) {
        const commandGroups = this.client.registry.groups;
        const commandsByCategory = {};

        commandGroups.forEach((group) => {
            const groupCommands = group.commands.map((command) => command.name);
            commandsByCategory[group.name] = groupCommands;
        });

        // Customizing this part to include the "servers" category
        const formattedCommands = Object.keys(commandsByCategory)
            .map((category) => {
                const categoryName = category === 'custom' ? 'Servers' : category;
                return `**${categoryName}**: ${commandsByCategory[category].join(', ')}`;
            })
            .join('\n');

        message.reply(`Available commands:\n${formattedCommands}`);
    }
};
