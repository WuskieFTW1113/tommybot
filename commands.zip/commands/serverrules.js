const { Command } = require('discord.js-commando');

module.exports = class ServerRulesCommand extends Command {
    constructor(client) {
        super(client, {
            name: 'serverrules',
            group: 'custom',
            memberName: 'serverrules',
            description: 'To set rules in the server description.',
        });
    }

    run(message) {
        // Provide the server rules guide URL to the user
        const rulesURL = 'https://wiki.gtaconnected.com/ServerRules';
        message.reply(`To learn how to set rules in the server description, please refer to this guide: ${rulesURL}`);
    }
};
