const { Command } = require('discord.js-commando');

module.exports = class AnticheatCommand extends Command {
    constructor(client) {
        super(client, {
            name: 'anticheat',
            group: 'custom',
            memberName: 'anticheat',
            description: 'Learn how to set up an anti-cheat system for your server.',
        });
    }

    run(message) {
        // Provide the anti-cheat setup guide URL to the user
        const anticheatURL = 'https://wiki.gtaconnected.com/Anticheat';
        message.reply(`To learn how to set up an anti-cheat system, please follow this guide: ${anticheatURL}`);
    }
};
