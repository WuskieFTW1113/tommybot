const { Command } = require('discord.js-commando');
const axios = require('axios');

module.exports = class ServerListCommand extends Command {
    constructor(client) {
        super(client, {
            name: 'serverlist',
            group: 'custom',
            memberName: 'serverlist',
            description: 'Lists available servers from masterlist.gtaconnected.com.',
        });
    }

    async run(message) {
        try {
            // Make an HTTP GET request to the masterlist website
            const response = await axios.get('https://masterlist.gtaconnected.com/');

            if (response.status === 200) {
                // Parse the HTML content of the page to extract relevant information
                // You can use a library like cheerio for this

                // Example: Extracting the entire page content
                const pageContent = response.data;

                // Now you can format and send the content to the user
                message.reply(`Here is the server list from masterlist.gtaconnected.com:\n${pageContent}`);
            } else {
                message.reply('Unable to fetch the server list. Please try again later.');
            }
        } catch (error) {
            console.error(error);
            message.reply('An error occurred while fetching the server list. Please try again later.');
        }
    }
};
