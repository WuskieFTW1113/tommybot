const { Command } = require('discord.js-commando');

module.exports = class PortForwardingCommand extends Command {
    constructor(client) {
        super(client, {
            name: 'portfw',
            group: 'custom',
            memberName: 'portfw',
            description: 'Teaches port forwarding.',
        });
    }

    run(message) {
        // Your code to teach port forwarding goes here
        message.reply('I will teach you how to port forward.');
    }
};
