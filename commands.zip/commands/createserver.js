const { Command } = require('discord.js-commando');

module.exports = class CreateServerCommand extends Command {
    constructor(client) {
        super(client, {
            name: 'createserver',
            group: 'custom',
            memberName: 'createserver',
            description: 'This is how you create a server.',
        });
    }

    run(message) {
        // Provide the guide URL to the user
        const guideURL = 'https://wiki.gtaconnected.com/GettingStarted';
        message.reply(`To learn how to create a server, please follow this guide: ${guideURL}`);
    }
};
