const { Command } = require('discord.js-commando');

module.exports = class ServerManualCommand extends Command {
    constructor(client) {
        super(client, {
            name: 'servermanual',
            group: 'custom',
            memberName: 'servermanual',
            description: 'This is the server manual.',
        });
    }

    run(message) {
        // Provide the manual URL to the user
        const manualURL = 'https://wiki.gtaconnected.com/ServerManual';
        message.reply(`To access the server manual, please follow this link: ${manualURL}`);
    }
};
