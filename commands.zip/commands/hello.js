const { Command } = require('discord.js-commando');

module.exports = class HelloCommand extends Command {
    constructor(client) {
        super(client, {
            name: 'hello',
            group: 'custom',
            memberName: 'hello',
            description: 'Say hello to Tommy.',
        });
    }

    run(message) {
        message.reply('Hey there, pal! I am a bot created to help you with anything envolving GTA Connected. If you need anything my commands are accessable with !cmds');
    }
};
