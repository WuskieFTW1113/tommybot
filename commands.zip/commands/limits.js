const { Command } = require('discord.js-commando');

module.exports = class LimitsCommand extends Command {
    constructor(client) {
        super(client, {
            name: 'limits',
            group: 'custom',
            memberName: 'limits',
            description: 'Shows the limits of the servers based on the game.',
        });
    }

    run(message) {
        // Provide the limits guide URL to the user
        const limitsURL = 'https://wiki.gtaconnected.com/Limits';
        message.reply(`To learn about server limits based on the game, please refer to this guide: ${limitsURL}`);
    }
};
